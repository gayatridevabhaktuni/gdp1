import UIKit

class LogoutViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var youAreLoggedOutLabel: UILabel!
	@IBOutlet private weak var line3ImageView: UIImageView!
	@IBOutlet private weak var reloginButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension LogoutViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		youAreLoggedOutLabel.textColor = UIColor.daisy
		youAreLoggedOutLabel.numberOfLines = 0
		youAreLoggedOutLabel.font = UIFont.textStyle10
		youAreLoggedOutLabel.textAlignment = .center
		youAreLoggedOutLabel.text = NSLocalizedString("you.are.logged.out", comment: "")


		reloginButton.layer.cornerRadius = 10
		reloginButton.layer.masksToBounds =  true
		reloginButton.backgroundColor = UIColor.seafoam
		reloginButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		reloginButton.setTitleColor(UIColor.daisy, for: .normal)
		reloginButton.titleLabel?.font = UIFont.textStyle2
		reloginButton.contentHorizontalAlignment = .center 
		reloginButton.contentEdgeInsets = UIEdgeInsets(top: 12, left: 13 , bottom: 12, right: 13)

		reloginButton.setTitle(NSLocalizedString("login.back.again", comment: ""),for: .normal)

		reloginButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openHomepagecontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

