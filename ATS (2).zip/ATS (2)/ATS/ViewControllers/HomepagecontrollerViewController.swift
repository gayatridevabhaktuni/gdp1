import UIKit

class HomepagecontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var adminLogoImageView: UIImageView!
	@IBOutlet private weak var rectangle4View: UIView!
	@IBOutlet private weak var nwLogoImageView: UIImageView!
	@IBOutlet private weak var facultyLoginButton: UIButton!
	@IBOutlet private weak var studentLoginButton: UIButton!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension HomepagecontrollerViewController {
	private func setupViews() {



		rectangle4View.backgroundColor = UIColor.pebble_75



		facultyLoginButton.layer.cornerRadius = 10
		facultyLoginButton.layer.masksToBounds =  true
		facultyLoginButton.backgroundColor = UIColor.seafoam
		facultyLoginButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		facultyLoginButton.setTitleColor(UIColor.daisy, for: .normal)
		facultyLoginButton.titleLabel?.font = UIFont.textStyle2
		facultyLoginButton.contentHorizontalAlignment = .center 
		facultyLoginButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 7 , bottom: 13, right: 7)

		facultyLoginButton.setTitle(NSLocalizedString("faculty", comment: ""),for: .normal)

		facultyLoginButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyhomepagecontroller), for: .touchUpInside)

		studentLoginButton.layer.cornerRadius = 10
		studentLoginButton.layer.masksToBounds =  true
		studentLoginButton.backgroundColor = UIColor.seafoam
		studentLoginButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		studentLoginButton.setTitleColor(UIColor.daisy, for: .normal)
		studentLoginButton.titleLabel?.font = UIFont.textStyle2
		studentLoginButton.contentHorizontalAlignment = .center 
		studentLoginButton.contentEdgeInsets = UIEdgeInsets(top: 12, left: 7 , bottom: 12, right: 7)

		studentLoginButton.setTitle(NSLocalizedString("student", comment: ""),for: .normal)

		studentLoginButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openStudenthomepagecontroller), for: .touchUpInside)


	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

