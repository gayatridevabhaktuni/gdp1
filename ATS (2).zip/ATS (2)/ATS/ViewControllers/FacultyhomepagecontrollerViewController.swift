import UIKit

class FacultyhomepagecontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var homePageButton: UIButton!
	@IBOutlet private weak var loginButton: UIButton!
	@IBOutlet private weak var createAccButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension FacultyhomepagecontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		homePageButton.setImage(UIImage(named: "user3") , for: .normal)

		homePageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openHomepagecontroller), for: .touchUpInside)

		loginButton.layer.cornerRadius = 10
		loginButton.layer.masksToBounds =  true
		loginButton.backgroundColor = UIColor.seafoam
		loginButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		loginButton.setTitleColor(UIColor.daisy, for: .normal)
		loginButton.titleLabel?.font = UIFont.textStyle2
		loginButton.contentHorizontalAlignment = .center 
		loginButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 19 , bottom: 13, right: 19)

		loginButton.setTitle(NSLocalizedString("login3", comment: ""),for: .normal)

		loginButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLoginfacultycontroller), for: .touchUpInside)

		createAccButton.layer.cornerRadius = 10
		createAccButton.layer.masksToBounds =  true
		createAccButton.backgroundColor = UIColor.seafoam
		createAccButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		createAccButton.setTitleColor(UIColor.daisy, for: .normal)
		createAccButton.titleLabel?.font = UIFont.textStyle2
		createAccButton.contentHorizontalAlignment = .center 
		createAccButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 19 , bottom: 13, right: 19)

		createAccButton.setTitle(NSLocalizedString("create.account", comment: ""),for: .normal)

		createAccButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openSignupfacultycontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

