import UIKit

class FacultyreportcontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var facultyPageButton: UIButton!
	@IBOutlet private weak var viewReportsLabel: UILabel!
	@IBOutlet private weak var line1ImageView: UIImageView!
	@IBOutlet private weak var image1ImageView: UIImageView!
	@IBOutlet private weak var rectangleView: UIView!
	@IBOutlet private weak var gdpLabel: UILabel!
	@IBOutlet private weak var rectangleView2: UIView!
	@IBOutlet private weak var gdpLabel2: UILabel!
	@IBOutlet private weak var rectangleView3: UIView!
	@IBOutlet private weak var gdpLabel3: UILabel!
	@IBOutlet private weak var rectangleView4: UIView!
	@IBOutlet private weak var gdpLabel4: UILabel!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension FacultyreportcontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		facultyPageButton.layer.cornerRadius = 22
		facultyPageButton.layer.masksToBounds =  true
		facultyPageButton.backgroundColor = UIColor.smoke
		facultyPageButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.1599999964237213,
		                    x: 4,
		                    y: 4,
		                    blur: 17,
		                    spread: 0)
		facultyPageButton.addShadow(color: UIColor(red:0.9166666865348816, green: 0.9166666865348816, blue: 0.9166666865348816, alpha: 1),
		                    alpha: 0.07999999821186066,
		                    x: -4,
		                    y: -4,
		                    blur: 17,
		                    spread: 0)

		facultyPageButton.setImage(UIImage(named: "vector3") , for: .normal)

		facultyPageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyselectioncontroller), for: .touchUpInside)

		viewReportsLabel.textColor = UIColor.daisy
		viewReportsLabel.numberOfLines = 0
		viewReportsLabel.font = UIFont.textStyle6
		viewReportsLabel.textAlignment = .center
		viewReportsLabel.text = NSLocalizedString("view.reports", comment: "")



		rectangleView.layer.cornerRadius = 5
		rectangleView.layer.masksToBounds =  true
		rectangleView.backgroundColor = UIColor.amethyst


		gdpLabel.textColor = UIColor.slate
		gdpLabel.numberOfLines = 0
		gdpLabel.font = UIFont.textStyle3
		gdpLabel.textAlignment = .left
		gdpLabel.text = NSLocalizedString("web.apps", comment: "")

		rectangleView2.layer.cornerRadius = 5
		rectangleView2.layer.masksToBounds =  true
		rectangleView2.backgroundColor = UIColor.amethyst2


		gdpLabel2.textColor = UIColor.slate
		gdpLabel2.numberOfLines = 0
		gdpLabel2.font = UIFont.textStyle3
		gdpLabel2.textAlignment = .left
		gdpLabel2.text = NSLocalizedString("java", comment: "")

		rectangleView3.layer.cornerRadius = 5
		rectangleView3.layer.masksToBounds =  true
		rectangleView3.backgroundColor = UIColor.marigold


		gdpLabel3.textColor = UIColor.slate
		gdpLabel3.numberOfLines = 0
		gdpLabel3.font = UIFont.textStyle3
		gdpLabel3.textAlignment = .left
		gdpLabel3.text = NSLocalizedString("ios", comment: "")

		rectangleView4.layer.cornerRadius = 5
		rectangleView4.layer.masksToBounds =  true
		rectangleView4.backgroundColor = UIColor.strawberry


		gdpLabel4.textColor = UIColor.slate
		gdpLabel4.numberOfLines = 0
		gdpLabel4.font = UIFont.textStyle3
		gdpLabel4.textAlignment = .left
		gdpLabel4.text = NSLocalizedString("android", comment: "")



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

