import UIKit

class RegistrationViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var registrationSuccessLabel: UILabel!
	@IBOutlet private weak var line2ImageView: UIImageView!
	@IBOutlet private weak var loginSuccessButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension RegistrationViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		registrationSuccessLabel.textColor = UIColor.daisy
		registrationSuccessLabel.numberOfLines = 0
		registrationSuccessLabel.font = UIFont.textStyle9
		registrationSuccessLabel.textAlignment = .center
		registrationSuccessLabel.text = NSLocalizedString("registration.success", comment: "")


		loginSuccessButton.layer.cornerRadius = 10
		loginSuccessButton.layer.masksToBounds =  true
		loginSuccessButton.backgroundColor = UIColor.seafoam
		loginSuccessButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		loginSuccessButton.setTitleColor(UIColor.daisy, for: .normal)
		loginSuccessButton.titleLabel?.font = UIFont.textStyle2
		loginSuccessButton.contentHorizontalAlignment = .center 
		loginSuccessButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 12 , bottom: 13, right: 12)

		loginSuccessButton.setTitle(NSLocalizedString("click.here.to.login", comment: ""),for: .normal)

		loginSuccessButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openHomepagecontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

