import UIKit

class SignupfacultycontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var homePageButton: UIButton!
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var createAccountLabel: UILabel!
	@IBOutlet private weak var mailAddressField: UITextField!
	@IBOutlet private weak var userNameField: UITextField!
	@IBOutlet private weak var passwordField: UITextField!
	@IBOutlet private weak var registerButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension SignupfacultycontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		homePageButton.setImage(UIImage(named: "user4") , for: .normal)

		homePageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openHomepagecontroller), for: .touchUpInside)

		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyhomepagecontroller), for: .touchUpInside)

		createAccountLabel.textColor = UIColor.daisy
		createAccountLabel.numberOfLines = 0
		createAccountLabel.font = UIFont.textStyle6
		createAccountLabel.textAlignment = .center
		createAccountLabel.text = NSLocalizedString("create.account2", comment: "")

		mailAddressField.layer.cornerRadius = 10
		mailAddressField.layer.masksToBounds =  true
		mailAddressField.backgroundColor = UIColor.spruce
		mailAddressField.textColor = UIColor.daisy
		mailAddressField.font = UIFont.textStyle3
		mailAddressField.textAlignment = .center
		mailAddressField.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 10, height: 45))

		mailAddressField.placeholder = NSLocalizedString("enter.your.email.address", comment: "")


		userNameField.layer.cornerRadius = 10
		userNameField.layer.masksToBounds =  true
		userNameField.backgroundColor = UIColor.spruce
		userNameField.textColor = UIColor.daisy
		userNameField.font = UIFont.textStyle3
		userNameField.textAlignment = .center
		userNameField.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 10, height: 45))

		userNameField.placeholder = NSLocalizedString("user.name", comment: "")


		passwordField.layer.cornerRadius = 10
		passwordField.layer.masksToBounds =  true
		passwordField.backgroundColor = UIColor.spruce
		passwordField.textColor = UIColor.daisy
		passwordField.font = UIFont.textStyle3
		passwordField.textAlignment = .center
		passwordField.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 10, height: 45))

		passwordField.placeholder = NSLocalizedString("password", comment: "")


		registerButton.layer.cornerRadius = 10
		registerButton.layer.masksToBounds =  true
		registerButton.backgroundColor = UIColor.seafoam
		registerButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		registerButton.setTitleColor(UIColor.daisy, for: .normal)
		registerButton.titleLabel?.font = UIFont.textStyle3
		registerButton.contentHorizontalAlignment = .center 
		registerButton.contentEdgeInsets = UIEdgeInsets(top: 6, left: 20 , bottom: 6, right: 20)

		registerButton.setTitle(NSLocalizedString("register", comment: ""),for: .normal)

		registerButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openRegistration), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

