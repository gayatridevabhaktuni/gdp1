import UIKit

class CameracontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var cameraLabel: UILabel!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension CameracontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openStudentselectioncontroller), for: .touchUpInside)

		logoutButton.setImage(UIImage(named: "logout6") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)

		cameraLabel.textColor = UIColor.daisy
		cameraLabel.numberOfLines = 0
		cameraLabel.font = UIFont.textStyle6
		cameraLabel.textAlignment = .center
		cameraLabel.text = NSLocalizedString("camera", comment: "")



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

