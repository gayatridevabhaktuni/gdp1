import UIKit

class FacultyselectioncontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var capture2ImageView: UIImageView!
	@IBOutlet private weak var capture21ImageView: UIImageView!
	@IBOutlet private weak var coursesButton: UIButton!
	@IBOutlet private weak var reportsButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension FacultyselectioncontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLoginfacultycontroller), for: .touchUpInside)

		logoutButton.setImage(UIImage(named: "logout3") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)



		coursesButton.layer.cornerRadius = 10
		coursesButton.layer.masksToBounds =  true
		coursesButton.backgroundColor = UIColor.seafoam
		coursesButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		coursesButton.setTitleColor(UIColor.daisy, for: .normal)
		coursesButton.titleLabel?.font = UIFont.textStyle2
		coursesButton.contentHorizontalAlignment = .center 
		coursesButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 14 , bottom: 13, right: 14)

		coursesButton.setTitle(NSLocalizedString("courses", comment: ""),for: .normal)

		coursesButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultycoursesselectioncontroller), for: .touchUpInside)

		reportsButton.layer.cornerRadius = 10
		reportsButton.layer.masksToBounds =  true
		reportsButton.backgroundColor = UIColor.seafoam
		reportsButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		reportsButton.setTitleColor(UIColor.daisy, for: .normal)
		reportsButton.titleLabel?.font = UIFont.textStyle2
		reportsButton.contentHorizontalAlignment = .center 
		reportsButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 11 , bottom: 13, right: 11)

		reportsButton.setTitle(NSLocalizedString("reports", comment: ""),for: .normal)

		reportsButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyreportcontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

