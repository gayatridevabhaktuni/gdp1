import UIKit

class StudentselectioncontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var capture2ImageView: UIImageView!
	@IBOutlet private weak var capture21ImageView: UIImageView!
	@IBOutlet private weak var checkAttendanceButton: UIButton!
	@IBOutlet private weak var recordAttandance: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension StudentselectioncontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		logoutButton.setImage(UIImage(named: "logout4") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)



		checkAttendanceButton.layer.cornerRadius = 10
		checkAttendanceButton.layer.masksToBounds =  true
		checkAttendanceButton.backgroundColor = UIColor.seafoam
		checkAttendanceButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		checkAttendanceButton.setTitleColor(UIColor.daisy, for: .normal)
		checkAttendanceButton.titleLabel?.font = UIFont.textStyle2
		checkAttendanceButton.contentHorizontalAlignment = .center 
		checkAttendanceButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 9 , bottom: 13, right: 9)

		checkAttendanceButton.setTitle(NSLocalizedString("check.attendance", comment: ""),for: .normal)

		checkAttendanceButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openStudentreportcontroller), for: .touchUpInside)

		recordAttandance.layer.cornerRadius = 10
		recordAttandance.layer.masksToBounds =  true
		recordAttandance.backgroundColor = UIColor.seafoam
		recordAttandance.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		recordAttandance.setTitleColor(UIColor.daisy, for: .normal)
		recordAttandance.titleLabel?.font = UIFont.textStyle2
		recordAttandance.contentHorizontalAlignment = .center 
		recordAttandance.contentEdgeInsets = UIEdgeInsets(top: 13, left: 9 , bottom: 13, right: 9)

		recordAttandance.setTitle(NSLocalizedString("record.attendance", comment: ""),for: .normal)

		recordAttandance.addTarget(self.coordinator, action: #selector(MainCoordinator.openCameracontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

