import UIKit

class LoginfacultycontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var loginLabel2: UILabel!
	@IBOutlet private weak var userName: UITextField!
	@IBOutlet private weak var password: UITextField!
	@IBOutlet private weak var forgotPasswordButton: UIButton!
	@IBOutlet private weak var loginPageButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension LoginfacultycontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyhomepagecontroller), for: .touchUpInside)

		loginLabel2.textColor = UIColor.daisy
		loginLabel2.numberOfLines = 0
		loginLabel2.font = UIFont.textStyle4
		loginLabel2.textAlignment = .center
		loginLabel2.text = NSLocalizedString("login2", comment: "")

		userName.layer.cornerRadius = 10
		userName.layer.masksToBounds =  true
        userName.backgroundColor = UIColor.spruce


		password.layer.cornerRadius = 10
		password.layer.masksToBounds =  true
        password.backgroundColor = UIColor.systemGray
        

		forgotPasswordButton.setTitleColor(UIColor.seafoam, for: .normal)
		forgotPasswordButton.titleLabel?.font = UIFont.textStyle
		forgotPasswordButton.contentHorizontalAlignment = .center 

		forgotPasswordButton.setTitle(NSLocalizedString("forgot.password", comment: ""),for: .normal)


		loginPageButton.layer.cornerRadius = 10
		loginPageButton.layer.masksToBounds =  true
		loginPageButton.backgroundColor = UIColor.seafoam
		loginPageButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		loginPageButton.setTitleColor(UIColor.daisy, for: .normal)
		loginPageButton.titleLabel?.font = UIFont.textStyle2
		loginPageButton.contentHorizontalAlignment = .center 
		loginPageButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 7 , bottom: 13, right: 7)

		loginPageButton.setTitle(NSLocalizedString("login", comment: ""),for: .normal)

		loginPageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyselectioncontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

