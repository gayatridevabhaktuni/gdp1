import UIKit

class StudenthomepagecontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var homePageButton: UIButton!
	@IBOutlet private weak var loginButton: UIButton!
	@IBOutlet private weak var createAccountButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension StudenthomepagecontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		homePageButton.setImage(UIImage(named: "user") , for: .normal)

		homePageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openHomepagecontroller), for: .touchUpInside)

		loginButton.layer.cornerRadius = 10
		loginButton.layer.masksToBounds =  true
		loginButton.backgroundColor = UIColor.seafoam
		loginButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		loginButton.setTitleColor(UIColor.daisy, for: .normal)
		loginButton.titleLabel?.font = UIFont.textStyle2
		loginButton.contentHorizontalAlignment = .center 
		loginButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 17 , bottom: 13, right: 17)

		loginButton.setTitle(NSLocalizedString("login3", comment: ""),for: .normal)

		loginButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLoginstudentcontroller), for: .touchUpInside)

		createAccountButton.layer.cornerRadius = 10
		createAccountButton.layer.masksToBounds =  true
		createAccountButton.backgroundColor = UIColor.seafoam
		createAccountButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		createAccountButton.setTitleColor(UIColor.daisy, for: .normal)
		createAccountButton.titleLabel?.font = UIFont.textStyle2
		createAccountButton.contentHorizontalAlignment = .center 
		createAccountButton.contentEdgeInsets = UIEdgeInsets(top: 13, left: 13 , bottom: 13, right: 13)

		createAccountButton.setTitle(NSLocalizedString("create.account", comment: ""),for: .normal)

		createAccountButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openSignupstudentcontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

