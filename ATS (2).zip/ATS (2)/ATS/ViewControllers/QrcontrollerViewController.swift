import UIKit

class QrcontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var homePageButton: UIButton!
	@IBOutlet private weak var label: UILabel!
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var logoutButton: UIButton!
	@IBOutlet private weak var scanTheQrCodeOfTheDeviceLabel: UILabel!
	@IBOutlet private weak var rectangle5View: UIView!
	@IBOutlet private weak var rectangle6View: UIView!
	@IBOutlet private weak var ellipse2View: UIView!
	@IBOutlet private weak var ellipse3View: UIView!
	@IBOutlet private weak var ellipse4View: UIView!
	@IBOutlet private weak var ellipse5View: UIView!
	@IBOutlet private weak var ellipse6View: UIView!
	@IBOutlet private weak var ellipse7View: UIView!
	@IBOutlet private weak var ellipse8View: UIView!
	@IBOutlet private weak var ellipse9View: UIView!
	@IBOutlet private weak var rectangle9View: UIView!
	@IBOutlet private weak var ellipse48View: UIView!
	@IBOutlet private weak var ellipse68View: UIView!
	@IBOutlet private weak var ellipse69View: UIView!
	@IBOutlet private weak var ellipse70View: UIView!
	@IBOutlet private weak var ellipse71View: UIView!
	@IBOutlet private weak var ellipse73View: UIView!
	@IBOutlet private weak var ellipse11View: UIView!
	@IBOutlet private weak var ellipse12View: UIView!
	@IBOutlet private weak var ellipse45View: UIView!
	@IBOutlet private weak var ellipse46View: UIView!
	@IBOutlet private weak var ellipse47View: UIView!
	@IBOutlet private weak var ellipse61View: UIView!
	@IBOutlet private weak var ellipse63View: UIView!
	@IBOutlet private weak var ellipse64View: UIView!
	@IBOutlet private weak var ellipse65View: UIView!
	@IBOutlet private weak var ellipse67View: UIView!
	@IBOutlet private weak var ellipse13View: UIView!
	@IBOutlet private weak var ellipse14View: UIView!
	@IBOutlet private weak var ellipse44View: UIView!
	@IBOutlet private weak var ellipse50View: UIView!
	@IBOutlet private weak var ellipse51View: UIView!
	@IBOutlet private weak var ellipse52View: UIView!
	@IBOutlet private weak var ellipse53View: UIView!
	@IBOutlet private weak var ellipse54View: UIView!
	@IBOutlet private weak var ellipse55View: UIView!
	@IBOutlet private weak var ellipse56View: UIView!
	@IBOutlet private weak var ellipse57View: UIView!
	@IBOutlet private weak var ellipse58View: UIView!
	@IBOutlet private weak var ellipse15View: UIView!
	@IBOutlet private weak var ellipse60View: UIView!
	@IBOutlet private weak var ellipse43View: UIView!
	@IBOutlet private weak var ellipse75View: UIView!
	@IBOutlet private weak var ellipse77View: UIView!
	@IBOutlet private weak var ellipse78View: UIView!
	@IBOutlet private weak var ellipse79View: UIView!
	@IBOutlet private weak var ellipse81View: UIView!
	@IBOutlet private weak var ellipse83View: UIView!
	@IBOutlet private weak var ellipse84View: UIView!
	@IBOutlet private weak var ellipse16View: UIView!
	@IBOutlet private weak var ellipse42View: UIView!
	@IBOutlet private weak var ellipse86View: UIView!
	@IBOutlet private weak var ellipse87View: UIView!
	@IBOutlet private weak var ellipse88View: UIView!
	@IBOutlet private weak var ellipse89View: UIView!
	@IBOutlet private weak var ellipse90View: UIView!
	@IBOutlet private weak var ellipse91View: UIView!
	@IBOutlet private weak var ellipse92View: UIView!
	@IBOutlet private weak var ellipse93View: UIView!
	@IBOutlet private weak var ellipse158View: UIView!
	@IBOutlet private weak var ellipse164View: UIView!
	@IBOutlet private weak var ellipse17View: UIView!
	@IBOutlet private weak var ellipse41View: UIView!
	@IBOutlet private weak var ellipse95View: UIView!
	@IBOutlet private weak var ellipse96View: UIView!
	@IBOutlet private weak var ellipse97View: UIView!
	@IBOutlet private weak var ellipse99View: UIView!
	@IBOutlet private weak var ellipse100View: UIView!
	@IBOutlet private weak var ellipse101View: UIView!
	@IBOutlet private weak var ellipse102View: UIView!
	@IBOutlet private weak var ellipse104View: UIView!
	@IBOutlet private weak var ellipse159View: UIView!
	@IBOutlet private weak var ellipse165View: UIView!
	@IBOutlet private weak var ellipse19View: UIView!
	@IBOutlet private weak var ellipse40View: UIView!
	@IBOutlet private weak var ellipse105View: UIView!
	@IBOutlet private weak var ellipse106View: UIView!
	@IBOutlet private weak var ellipse107View: UIView!
	@IBOutlet private weak var ellipse108View: UIView!
	@IBOutlet private weak var ellipse109View: UIView!
	@IBOutlet private weak var ellipse110View: UIView!
	@IBOutlet private weak var ellipse111View: UIView!
	@IBOutlet private weak var ellipse112View: UIView!
	@IBOutlet private weak var ellipse113View: UIView!
	@IBOutlet private weak var ellipse114View: UIView!
	@IBOutlet private weak var ellipse160View: UIView!
	@IBOutlet private weak var ellipse166View: UIView!
	@IBOutlet private weak var ellipse18View: UIView!
	@IBOutlet private weak var ellipse115View: UIView!
	@IBOutlet private weak var ellipse116View: UIView!
	@IBOutlet private weak var ellipse117View: UIView!
	@IBOutlet private weak var ellipse119View: UIView!
	@IBOutlet private weak var ellipse120View: UIView!
	@IBOutlet private weak var ellipse121View: UIView!
	@IBOutlet private weak var ellipse123View: UIView!
	@IBOutlet private weak var ellipse124View: UIView!
	@IBOutlet private weak var ellipse161View: UIView!
	@IBOutlet private weak var ellipse167View: UIView!
	@IBOutlet private weak var ellipse125View: UIView!
	@IBOutlet private weak var ellipse126View: UIView!
	@IBOutlet private weak var ellipse128View: UIView!
	@IBOutlet private weak var ellipse129View: UIView!
	@IBOutlet private weak var ellipse131View: UIView!
	@IBOutlet private weak var ellipse133View: UIView!
	@IBOutlet private weak var ellipse134View: UIView!
	@IBOutlet private weak var ellipse162View: UIView!
	@IBOutlet private weak var ellipse20View: UIView!
	@IBOutlet private weak var ellipse37View: UIView!
	@IBOutlet private weak var ellipse135View: UIView!
	@IBOutlet private weak var ellipse136View: UIView!
	@IBOutlet private weak var ellipse138View: UIView!
	@IBOutlet private weak var ellipse139View: UIView!
	@IBOutlet private weak var ellipse140View: UIView!
	@IBOutlet private weak var ellipse141View: UIView!
	@IBOutlet private weak var ellipse143View: UIView!
	@IBOutlet private weak var ellipse144View: UIView!
	@IBOutlet private weak var ellipse163View: UIView!
	@IBOutlet private weak var ellipse169View: UIView!
	@IBOutlet private weak var ellipse21View: UIView!
	@IBOutlet private weak var ellipse35View: UIView!
	@IBOutlet private weak var ellipse36View: UIView!
	@IBOutlet private weak var ellipse145View: UIView!
	@IBOutlet private weak var ellipse146View: UIView!
	@IBOutlet private weak var ellipse147View: UIView!
	@IBOutlet private weak var ellipse149View: UIView!
	@IBOutlet private weak var ellipse150View: UIView!
	@IBOutlet private weak var ellipse151View: UIView!
	@IBOutlet private weak var ellipse23View: UIView!
	@IBOutlet private weak var ellipse22View: UIView!
	@IBOutlet private weak var ellipse34View: UIView!
	@IBOutlet private weak var rectangle3View: UIView!
	@IBOutlet private weak var ellipse152View: UIView!
	@IBOutlet private weak var ellipse153View: UIView!
	@IBOutlet private weak var ellipse154View: UIView!
	@IBOutlet private weak var ellipse156View: UIView!
	@IBOutlet private weak var ellipse157View: UIView!
	@IBOutlet private weak var ellipse24View: UIView!
	@IBOutlet private weak var rectangle4View: UIView!
	@IBOutlet private weak var ellipse33View: UIView!
	@IBOutlet private weak var rectangle12View: UIView!
	@IBOutlet private weak var rectangle11View: UIView!
	@IBOutlet private weak var ellipse25View: UIView!
	@IBOutlet private weak var ellipse32View: UIView!
	@IBOutlet private weak var ellipse31View: UIView!
	@IBOutlet private weak var ellipse30View: UIView!
	@IBOutlet private weak var ellipse29View: UIView!
	@IBOutlet private weak var ellipse27View: UIView!
	@IBOutlet private weak var ellipse26View: UIView!
	@IBOutlet private weak var theQrCodeWillBeAutomaticallyDetectedWhenYouPositionItBetweenTheGuideLinesLabel: UILabel!
	@IBOutlet private weak var refreshButton: UIButton!
	@IBOutlet private weak var timeLimitButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension QrcontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		homePageButton.layer.cornerRadius = 22
		homePageButton.layer.masksToBounds =  true
		homePageButton.backgroundColor = UIColor.smoke
		homePageButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.1599999964237213,
		                    x: 4,
		                    y: 4,
		                    blur: 17,
		                    spread: 0)
		homePageButton.addShadow(color: UIColor(red:0.9166666865348816, green: 0.9166666865348816, blue: 0.9166666865348816, alpha: 1),
		                    alpha: 0.07999999821186066,
		                    x: -4,
		                    y: -4,
		                    blur: 17,
		                    spread: 0)

		homePageButton.setImage(UIImage(named: "vector") , for: .normal)

		homePageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openFacultyselectioncontroller), for: .touchUpInside)

		label.textColor = UIColor.daisy
		label.numberOfLines = 0
		label.font = UIFont.textStyle5
		label.textAlignment = .center
		label.text = NSLocalizedString("00", comment: "")

		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openTimeslotcontroller), for: .touchUpInside)

		logoutButton.setImage(UIImage(named: "logout2") , for: .normal)

		logoutButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openLogout), for: .touchUpInside)

		scanTheQrCodeOfTheDeviceLabel.textColor = UIColor.daisy
		scanTheQrCodeOfTheDeviceLabel.numberOfLines = 0
		scanTheQrCodeOfTheDeviceLabel.font = UIFont.textStyle7
		scanTheQrCodeOfTheDeviceLabel.textAlignment = .center
		scanTheQrCodeOfTheDeviceLabel.text = NSLocalizedString("scan.the.qr.code.of.the.device", comment: "")

		rectangle5View.layer.borderColor = UIColor.daisy.cgColor
		rectangle5View.layer.borderWidth =  4


		rectangle6View.layer.borderColor = UIColor.daisy.cgColor
		rectangle6View.layer.borderWidth =  4
		rectangle6View.backgroundColor = UIColor.cloud


		ellipse2View.layer.cornerRadius = 8
		ellipse2View.layer.masksToBounds =  true
		ellipse2View.backgroundColor = UIColor.daisy


		ellipse3View.layer.cornerRadius = 8
		ellipse3View.layer.masksToBounds =  true
		ellipse3View.backgroundColor = UIColor.daisy


		ellipse4View.layer.cornerRadius = 8
		ellipse4View.layer.masksToBounds =  true
		ellipse4View.backgroundColor = UIColor.daisy


		ellipse5View.layer.cornerRadius = 8
		ellipse5View.layer.masksToBounds =  true
		ellipse5View.backgroundColor = UIColor.daisy


		ellipse6View.layer.cornerRadius = 8
		ellipse6View.layer.masksToBounds =  true
		ellipse6View.backgroundColor = UIColor.daisy


		ellipse7View.layer.cornerRadius = 8
		ellipse7View.layer.masksToBounds =  true
		ellipse7View.backgroundColor = UIColor.daisy


		ellipse8View.layer.cornerRadius = 8
		ellipse8View.layer.masksToBounds =  true
		ellipse8View.backgroundColor = UIColor.daisy


		ellipse9View.layer.cornerRadius = 8
		ellipse9View.layer.masksToBounds =  true
		ellipse9View.backgroundColor = UIColor.daisy


		rectangle9View.backgroundColor = UIColor.cloud


		ellipse48View.layer.cornerRadius = 8
		ellipse48View.layer.masksToBounds =  true
		ellipse48View.backgroundColor = UIColor.daisy


		ellipse68View.layer.cornerRadius = 8
		ellipse68View.layer.masksToBounds =  true
		ellipse68View.backgroundColor = UIColor.daisy


		ellipse69View.layer.cornerRadius = 8
		ellipse69View.layer.masksToBounds =  true
		ellipse69View.backgroundColor = UIColor.daisy


		ellipse70View.layer.cornerRadius = 8
		ellipse70View.layer.masksToBounds =  true
		ellipse70View.backgroundColor = UIColor.daisy


		ellipse71View.layer.cornerRadius = 8
		ellipse71View.layer.masksToBounds =  true
		ellipse71View.backgroundColor = UIColor.daisy


		ellipse73View.layer.cornerRadius = 8
		ellipse73View.layer.masksToBounds =  true
		ellipse73View.backgroundColor = UIColor.daisy


		ellipse11View.layer.cornerRadius = 8
		ellipse11View.layer.masksToBounds =  true
		ellipse11View.backgroundColor = UIColor.daisy


		ellipse12View.layer.cornerRadius = 8
		ellipse12View.layer.masksToBounds =  true
		ellipse12View.backgroundColor = UIColor.daisy


		ellipse45View.layer.cornerRadius = 8
		ellipse45View.layer.masksToBounds =  true
		ellipse45View.backgroundColor = UIColor.daisy


		ellipse46View.layer.cornerRadius = 8
		ellipse46View.layer.masksToBounds =  true
		ellipse46View.backgroundColor = UIColor.daisy


		ellipse47View.layer.cornerRadius = 8
		ellipse47View.layer.masksToBounds =  true
		ellipse47View.backgroundColor = UIColor.daisy


		ellipse61View.layer.cornerRadius = 8
		ellipse61View.layer.masksToBounds =  true
		ellipse61View.backgroundColor = UIColor.daisy


		ellipse63View.layer.cornerRadius = 8
		ellipse63View.layer.masksToBounds =  true
		ellipse63View.backgroundColor = UIColor.daisy


		ellipse64View.layer.cornerRadius = 8
		ellipse64View.layer.masksToBounds =  true
		ellipse64View.backgroundColor = UIColor.daisy


		ellipse65View.layer.cornerRadius = 8
		ellipse65View.layer.masksToBounds =  true
		ellipse65View.backgroundColor = UIColor.daisy


		ellipse67View.layer.cornerRadius = 8
		ellipse67View.layer.masksToBounds =  true
		ellipse67View.backgroundColor = UIColor.daisy


		ellipse13View.layer.cornerRadius = 8
		ellipse13View.layer.masksToBounds =  true
		ellipse13View.backgroundColor = UIColor.daisy


		ellipse14View.layer.cornerRadius = 8
		ellipse14View.layer.masksToBounds =  true
		ellipse14View.backgroundColor = UIColor.daisy


		ellipse44View.layer.cornerRadius = 8
		ellipse44View.layer.masksToBounds =  true
		ellipse44View.backgroundColor = UIColor.daisy


		ellipse50View.layer.cornerRadius = 8
		ellipse50View.layer.masksToBounds =  true
		ellipse50View.backgroundColor = UIColor.daisy


		ellipse51View.layer.cornerRadius = 8
		ellipse51View.layer.masksToBounds =  true
		ellipse51View.backgroundColor = UIColor.daisy


		ellipse52View.layer.cornerRadius = 8
		ellipse52View.layer.masksToBounds =  true
		ellipse52View.backgroundColor = UIColor.daisy


		ellipse53View.layer.cornerRadius = 8
		ellipse53View.layer.masksToBounds =  true
		ellipse53View.backgroundColor = UIColor.daisy


		ellipse54View.layer.cornerRadius = 8
		ellipse54View.layer.masksToBounds =  true
		ellipse54View.backgroundColor = UIColor.daisy


		ellipse55View.layer.cornerRadius = 8
		ellipse55View.layer.masksToBounds =  true
		ellipse55View.backgroundColor = UIColor.daisy


		ellipse56View.layer.cornerRadius = 8
		ellipse56View.layer.masksToBounds =  true
		ellipse56View.backgroundColor = UIColor.daisy


		ellipse57View.layer.cornerRadius = 8
		ellipse57View.layer.masksToBounds =  true
		ellipse57View.backgroundColor = UIColor.daisy


		ellipse58View.layer.cornerRadius = 8
		ellipse58View.layer.masksToBounds =  true
		ellipse58View.backgroundColor = UIColor.daisy


		ellipse15View.layer.cornerRadius = 8
		ellipse15View.layer.masksToBounds =  true
		ellipse15View.backgroundColor = UIColor.daisy


		ellipse60View.layer.cornerRadius = 8
		ellipse60View.layer.masksToBounds =  true
		ellipse60View.backgroundColor = UIColor.daisy


		ellipse43View.layer.cornerRadius = 8
		ellipse43View.layer.masksToBounds =  true
		ellipse43View.backgroundColor = UIColor.daisy


		ellipse75View.layer.cornerRadius = 8
		ellipse75View.layer.masksToBounds =  true
		ellipse75View.backgroundColor = UIColor.daisy


		ellipse77View.layer.cornerRadius = 8
		ellipse77View.layer.masksToBounds =  true
		ellipse77View.backgroundColor = UIColor.daisy


		ellipse78View.layer.cornerRadius = 8
		ellipse78View.layer.masksToBounds =  true
		ellipse78View.backgroundColor = UIColor.daisy


		ellipse79View.layer.cornerRadius = 8
		ellipse79View.layer.masksToBounds =  true
		ellipse79View.backgroundColor = UIColor.daisy


		ellipse81View.layer.cornerRadius = 8
		ellipse81View.layer.masksToBounds =  true
		ellipse81View.backgroundColor = UIColor.daisy


		ellipse83View.layer.cornerRadius = 8
		ellipse83View.layer.masksToBounds =  true
		ellipse83View.backgroundColor = UIColor.daisy


		ellipse84View.layer.cornerRadius = 8
		ellipse84View.layer.masksToBounds =  true
		ellipse84View.backgroundColor = UIColor.daisy


		ellipse16View.layer.cornerRadius = 8
		ellipse16View.layer.masksToBounds =  true
		ellipse16View.backgroundColor = UIColor.daisy


		ellipse42View.layer.cornerRadius = 8
		ellipse42View.layer.masksToBounds =  true
		ellipse42View.backgroundColor = UIColor.daisy


		ellipse86View.layer.cornerRadius = 8
		ellipse86View.layer.masksToBounds =  true
		ellipse86View.backgroundColor = UIColor.daisy


		ellipse87View.layer.cornerRadius = 8
		ellipse87View.layer.masksToBounds =  true
		ellipse87View.backgroundColor = UIColor.daisy


		ellipse88View.layer.cornerRadius = 8
		ellipse88View.layer.masksToBounds =  true
		ellipse88View.backgroundColor = UIColor.daisy


		ellipse89View.layer.cornerRadius = 8
		ellipse89View.layer.masksToBounds =  true
		ellipse89View.backgroundColor = UIColor.daisy


		ellipse90View.layer.cornerRadius = 8
		ellipse90View.layer.masksToBounds =  true
		ellipse90View.backgroundColor = UIColor.daisy


		ellipse91View.layer.cornerRadius = 8
		ellipse91View.layer.masksToBounds =  true
		ellipse91View.backgroundColor = UIColor.daisy


		ellipse92View.layer.cornerRadius = 8
		ellipse92View.layer.masksToBounds =  true
		ellipse92View.backgroundColor = UIColor.daisy


		ellipse93View.layer.cornerRadius = 8
		ellipse93View.layer.masksToBounds =  true
		ellipse93View.backgroundColor = UIColor.daisy


		ellipse158View.layer.cornerRadius = 8
		ellipse158View.layer.masksToBounds =  true
		ellipse158View.backgroundColor = UIColor.daisy


		ellipse164View.layer.cornerRadius = 8
		ellipse164View.layer.masksToBounds =  true
		ellipse164View.backgroundColor = UIColor.daisy


		ellipse17View.layer.cornerRadius = 8
		ellipse17View.layer.masksToBounds =  true
		ellipse17View.backgroundColor = UIColor.daisy


		ellipse41View.layer.cornerRadius = 8
		ellipse41View.layer.masksToBounds =  true
		ellipse41View.backgroundColor = UIColor.daisy


		ellipse95View.layer.cornerRadius = 8
		ellipse95View.layer.masksToBounds =  true
		ellipse95View.backgroundColor = UIColor.daisy


		ellipse96View.layer.cornerRadius = 8
		ellipse96View.layer.masksToBounds =  true
		ellipse96View.backgroundColor = UIColor.daisy


		ellipse97View.layer.cornerRadius = 8
		ellipse97View.layer.masksToBounds =  true
		ellipse97View.backgroundColor = UIColor.daisy


		ellipse99View.layer.cornerRadius = 8
		ellipse99View.layer.masksToBounds =  true
		ellipse99View.backgroundColor = UIColor.daisy


		ellipse100View.layer.cornerRadius = 8
		ellipse100View.layer.masksToBounds =  true
		ellipse100View.backgroundColor = UIColor.daisy


		ellipse101View.layer.cornerRadius = 8
		ellipse101View.layer.masksToBounds =  true
		ellipse101View.backgroundColor = UIColor.daisy


		ellipse102View.layer.cornerRadius = 8
		ellipse102View.layer.masksToBounds =  true
		ellipse102View.backgroundColor = UIColor.daisy


		ellipse104View.layer.cornerRadius = 8
		ellipse104View.layer.masksToBounds =  true
		ellipse104View.backgroundColor = UIColor.daisy


		ellipse159View.layer.cornerRadius = 8
		ellipse159View.layer.masksToBounds =  true
		ellipse159View.backgroundColor = UIColor.daisy


		ellipse165View.layer.cornerRadius = 8
		ellipse165View.layer.masksToBounds =  true
		ellipse165View.backgroundColor = UIColor.daisy


		ellipse19View.layer.cornerRadius = 8
		ellipse19View.layer.masksToBounds =  true
		ellipse19View.backgroundColor = UIColor.daisy


		ellipse40View.layer.cornerRadius = 8
		ellipse40View.layer.masksToBounds =  true
		ellipse40View.backgroundColor = UIColor.daisy


		ellipse105View.layer.cornerRadius = 8
		ellipse105View.layer.masksToBounds =  true
		ellipse105View.backgroundColor = UIColor.daisy


		ellipse106View.layer.cornerRadius = 8
		ellipse106View.layer.masksToBounds =  true
		ellipse106View.backgroundColor = UIColor.daisy


		ellipse107View.layer.cornerRadius = 8
		ellipse107View.layer.masksToBounds =  true
		ellipse107View.backgroundColor = UIColor.daisy


		ellipse108View.layer.cornerRadius = 8
		ellipse108View.layer.masksToBounds =  true
		ellipse108View.backgroundColor = UIColor.daisy


		ellipse109View.layer.cornerRadius = 8
		ellipse109View.layer.masksToBounds =  true
		ellipse109View.backgroundColor = UIColor.daisy


		ellipse110View.layer.cornerRadius = 8
		ellipse110View.layer.masksToBounds =  true
		ellipse110View.backgroundColor = UIColor.daisy


		ellipse111View.layer.cornerRadius = 8
		ellipse111View.layer.masksToBounds =  true
		ellipse111View.backgroundColor = UIColor.daisy


		ellipse112View.layer.cornerRadius = 8
		ellipse112View.layer.masksToBounds =  true
		ellipse112View.backgroundColor = UIColor.daisy


		ellipse113View.layer.cornerRadius = 8
		ellipse113View.layer.masksToBounds =  true
		ellipse113View.backgroundColor = UIColor.daisy


		ellipse114View.layer.cornerRadius = 8
		ellipse114View.layer.masksToBounds =  true
		ellipse114View.backgroundColor = UIColor.daisy


		ellipse160View.layer.cornerRadius = 8
		ellipse160View.layer.masksToBounds =  true
		ellipse160View.backgroundColor = UIColor.daisy


		ellipse166View.layer.cornerRadius = 8
		ellipse166View.layer.masksToBounds =  true
		ellipse166View.backgroundColor = UIColor.daisy


		ellipse18View.layer.cornerRadius = 8
		ellipse18View.layer.masksToBounds =  true
		ellipse18View.backgroundColor = UIColor.daisy


		ellipse115View.layer.cornerRadius = 8
		ellipse115View.layer.masksToBounds =  true
		ellipse115View.backgroundColor = UIColor.daisy


		ellipse116View.layer.cornerRadius = 8
		ellipse116View.layer.masksToBounds =  true
		ellipse116View.backgroundColor = UIColor.daisy


		ellipse117View.layer.cornerRadius = 8
		ellipse117View.layer.masksToBounds =  true
		ellipse117View.backgroundColor = UIColor.daisy


		ellipse119View.layer.cornerRadius = 8
		ellipse119View.layer.masksToBounds =  true
		ellipse119View.backgroundColor = UIColor.daisy


		ellipse120View.layer.cornerRadius = 8
		ellipse120View.layer.masksToBounds =  true
		ellipse120View.backgroundColor = UIColor.daisy


		ellipse121View.layer.cornerRadius = 8
		ellipse121View.layer.masksToBounds =  true
		ellipse121View.backgroundColor = UIColor.daisy


		ellipse123View.layer.cornerRadius = 8
		ellipse123View.layer.masksToBounds =  true
		ellipse123View.backgroundColor = UIColor.daisy


		ellipse124View.layer.cornerRadius = 8
		ellipse124View.layer.masksToBounds =  true
		ellipse124View.backgroundColor = UIColor.daisy


		ellipse161View.layer.cornerRadius = 8
		ellipse161View.layer.masksToBounds =  true
		ellipse161View.backgroundColor = UIColor.daisy


		ellipse167View.layer.cornerRadius = 8
		ellipse167View.layer.masksToBounds =  true
		ellipse167View.backgroundColor = UIColor.daisy


		ellipse125View.layer.cornerRadius = 8
		ellipse125View.layer.masksToBounds =  true
		ellipse125View.backgroundColor = UIColor.daisy


		ellipse126View.layer.cornerRadius = 8
		ellipse126View.layer.masksToBounds =  true
		ellipse126View.backgroundColor = UIColor.daisy


		ellipse128View.layer.cornerRadius = 8
		ellipse128View.layer.masksToBounds =  true
		ellipse128View.backgroundColor = UIColor.daisy


		ellipse129View.layer.cornerRadius = 8
		ellipse129View.layer.masksToBounds =  true
		ellipse129View.backgroundColor = UIColor.daisy


		ellipse131View.layer.cornerRadius = 8
		ellipse131View.layer.masksToBounds =  true
		ellipse131View.backgroundColor = UIColor.daisy


		ellipse133View.layer.cornerRadius = 8
		ellipse133View.layer.masksToBounds =  true
		ellipse133View.backgroundColor = UIColor.daisy


		ellipse134View.layer.cornerRadius = 8
		ellipse134View.layer.masksToBounds =  true
		ellipse134View.backgroundColor = UIColor.daisy


		ellipse162View.layer.cornerRadius = 8
		ellipse162View.layer.masksToBounds =  true
		ellipse162View.backgroundColor = UIColor.daisy


		ellipse20View.layer.cornerRadius = 8
		ellipse20View.layer.masksToBounds =  true
		ellipse20View.backgroundColor = UIColor.daisy


		ellipse37View.layer.cornerRadius = 8
		ellipse37View.layer.masksToBounds =  true
		ellipse37View.backgroundColor = UIColor.daisy


		ellipse135View.layer.cornerRadius = 8
		ellipse135View.layer.masksToBounds =  true
		ellipse135View.backgroundColor = UIColor.daisy


		ellipse136View.layer.cornerRadius = 8
		ellipse136View.layer.masksToBounds =  true
		ellipse136View.backgroundColor = UIColor.daisy


		ellipse138View.layer.cornerRadius = 8
		ellipse138View.layer.masksToBounds =  true
		ellipse138View.backgroundColor = UIColor.daisy


		ellipse139View.layer.cornerRadius = 8
		ellipse139View.layer.masksToBounds =  true
		ellipse139View.backgroundColor = UIColor.daisy


		ellipse140View.layer.cornerRadius = 8
		ellipse140View.layer.masksToBounds =  true
		ellipse140View.backgroundColor = UIColor.daisy


		ellipse141View.layer.cornerRadius = 8
		ellipse141View.layer.masksToBounds =  true
		ellipse141View.backgroundColor = UIColor.daisy


		ellipse143View.layer.cornerRadius = 8
		ellipse143View.layer.masksToBounds =  true
		ellipse143View.backgroundColor = UIColor.daisy


		ellipse144View.layer.cornerRadius = 8
		ellipse144View.layer.masksToBounds =  true
		ellipse144View.backgroundColor = UIColor.daisy


		ellipse163View.layer.cornerRadius = 8
		ellipse163View.layer.masksToBounds =  true
		ellipse163View.backgroundColor = UIColor.daisy


		ellipse169View.layer.cornerRadius = 8
		ellipse169View.layer.masksToBounds =  true
		ellipse169View.backgroundColor = UIColor.daisy


		ellipse21View.layer.cornerRadius = 8
		ellipse21View.layer.masksToBounds =  true
		ellipse21View.backgroundColor = UIColor.daisy


		ellipse35View.layer.cornerRadius = 8
		ellipse35View.layer.masksToBounds =  true
		ellipse35View.backgroundColor = UIColor.daisy


		ellipse36View.layer.cornerRadius = 8
		ellipse36View.layer.masksToBounds =  true
		ellipse36View.backgroundColor = UIColor.daisy


		ellipse145View.layer.cornerRadius = 8
		ellipse145View.layer.masksToBounds =  true
		ellipse145View.backgroundColor = UIColor.daisy


		ellipse146View.layer.cornerRadius = 8
		ellipse146View.layer.masksToBounds =  true
		ellipse146View.backgroundColor = UIColor.daisy


		ellipse147View.layer.cornerRadius = 8
		ellipse147View.layer.masksToBounds =  true
		ellipse147View.backgroundColor = UIColor.daisy


		ellipse149View.layer.cornerRadius = 8
		ellipse149View.layer.masksToBounds =  true
		ellipse149View.backgroundColor = UIColor.daisy


		ellipse150View.layer.cornerRadius = 8
		ellipse150View.layer.masksToBounds =  true
		ellipse150View.backgroundColor = UIColor.daisy


		ellipse151View.layer.cornerRadius = 8
		ellipse151View.layer.masksToBounds =  true
		ellipse151View.backgroundColor = UIColor.daisy


		ellipse23View.layer.cornerRadius = 8
		ellipse23View.layer.masksToBounds =  true
		ellipse23View.backgroundColor = UIColor.daisy


		ellipse22View.layer.cornerRadius = 8
		ellipse22View.layer.masksToBounds =  true
		ellipse22View.backgroundColor = UIColor.daisy


		ellipse34View.layer.cornerRadius = 8
		ellipse34View.layer.masksToBounds =  true
		ellipse34View.backgroundColor = UIColor.daisy


		rectangle3View.layer.borderColor = UIColor.daisy.cgColor
		rectangle3View.layer.borderWidth =  4


		ellipse152View.layer.cornerRadius = 8
		ellipse152View.layer.masksToBounds =  true
		ellipse152View.backgroundColor = UIColor.daisy


		ellipse153View.layer.cornerRadius = 8
		ellipse153View.layer.masksToBounds =  true
		ellipse153View.backgroundColor = UIColor.daisy


		ellipse154View.layer.cornerRadius = 8
		ellipse154View.layer.masksToBounds =  true
		ellipse154View.backgroundColor = UIColor.daisy


		ellipse156View.layer.cornerRadius = 8
		ellipse156View.layer.masksToBounds =  true
		ellipse156View.backgroundColor = UIColor.daisy


		ellipse157View.layer.cornerRadius = 8
		ellipse157View.layer.masksToBounds =  true
		ellipse157View.backgroundColor = UIColor.daisy


		ellipse24View.layer.cornerRadius = 8
		ellipse24View.layer.masksToBounds =  true
		ellipse24View.backgroundColor = UIColor.daisy


		rectangle4View.layer.borderColor = UIColor.daisy.cgColor
		rectangle4View.layer.borderWidth =  4


		ellipse33View.layer.cornerRadius = 8
		ellipse33View.layer.masksToBounds =  true
		ellipse33View.backgroundColor = UIColor.daisy


		rectangle12View.layer.borderColor = UIColor.daisy.cgColor
		rectangle12View.layer.borderWidth =  4
		rectangle12View.backgroundColor = UIColor.cloud


		rectangle11View.layer.borderColor = UIColor.daisy.cgColor
		rectangle11View.layer.borderWidth =  4
		rectangle11View.backgroundColor = UIColor.cloud


		ellipse25View.layer.cornerRadius = 8
		ellipse25View.layer.masksToBounds =  true
		ellipse25View.backgroundColor = UIColor.daisy


		ellipse32View.layer.cornerRadius = 8
		ellipse32View.layer.masksToBounds =  true
		ellipse32View.backgroundColor = UIColor.daisy


		ellipse31View.layer.cornerRadius = 8
		ellipse31View.layer.masksToBounds =  true
		ellipse31View.backgroundColor = UIColor.daisy


		ellipse30View.layer.cornerRadius = 8
		ellipse30View.layer.masksToBounds =  true
		ellipse30View.backgroundColor = UIColor.daisy


		ellipse29View.layer.cornerRadius = 8
		ellipse29View.layer.masksToBounds =  true
		ellipse29View.backgroundColor = UIColor.daisy


		ellipse27View.layer.cornerRadius = 8
		ellipse27View.layer.masksToBounds =  true
		ellipse27View.backgroundColor = UIColor.daisy


		ellipse26View.layer.cornerRadius = 8
		ellipse26View.layer.masksToBounds =  true
		ellipse26View.backgroundColor = UIColor.daisy


		theQrCodeWillBeAutomaticallyDetectedWhenYouPositionItBetweenTheGuideLinesLabel.textColor = UIColor.daisy_82
		theQrCodeWillBeAutomaticallyDetectedWhenYouPositionItBetweenTheGuideLinesLabel.numberOfLines = 0
		theQrCodeWillBeAutomaticallyDetectedWhenYouPositionItBetweenTheGuideLinesLabel.font = UIFont.textStyle8
		theQrCodeWillBeAutomaticallyDetectedWhenYouPositionItBetweenTheGuideLinesLabel.textAlignment = .center
		theQrCodeWillBeAutomaticallyDetectedWhenYouPositionItBetweenTheGuideLinesLabel.text = NSLocalizedString("the.qr.code.will.be.automatically.detectedwhen.you", comment: "")

		refreshButton.layer.borderColor = UIColor.daisy_33.cgColor
		refreshButton.layer.borderWidth =  1
		refreshButton.layer.cornerRadius = 30
		refreshButton.layer.masksToBounds =  true

		refreshButton.setImage(UIImage(named: "fluentarrowsync20filled") , for: .normal)


		timeLimitButton.layer.cornerRadius = 10
		timeLimitButton.layer.masksToBounds =  true
		timeLimitButton.backgroundColor = UIColor.seafoam
		timeLimitButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		timeLimitButton.setTitleColor(UIColor.daisy, for: .normal)
		timeLimitButton.titleLabel?.font = UIFont.textStyle3
		timeLimitButton.contentHorizontalAlignment = .center 
		timeLimitButton.contentEdgeInsets = UIEdgeInsets(top: 6, left: 17 , bottom: 6, right: 17)

		timeLimitButton.setTitle(NSLocalizedString("time.limit", comment: ""),for: .normal)

		timeLimitButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openTimelimitcontroller), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

