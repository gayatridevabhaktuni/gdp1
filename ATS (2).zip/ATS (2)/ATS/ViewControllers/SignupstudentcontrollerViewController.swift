import UIKit

class SignupstudentcontrollerViewController: UIViewController, Storyboarded {
	var coordinator: MainCoordinator?

	// MARK: - Properties
	@IBOutlet private weak var homePageButton: UIButton!
	@IBOutlet private weak var previousButton: UIButton!
	@IBOutlet private weak var createAccountLabel: UILabel!
	@IBOutlet private weak var email: UITextField!
	@IBOutlet private weak var number: UITextField!
	@IBOutlet private weak var userName: UITextField!
	@IBOutlet private weak var password: UITextField!
	@IBOutlet private weak var registerButton: UIButton!
	@IBOutlet private weak var vectorsImageView: UIImageView!

	override func viewDidLoad() {
		super.viewDidLoad()
		setupViews()
		setupLayout()
	}

}

extension SignupstudentcontrollerViewController {
	private func setupViews() {

		self.view.backgroundColor = UIColor.peacock


		homePageButton.setImage(UIImage(named: "user2") , for: .normal)

		homePageButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openStudenthomepagecontroller), for: .touchUpInside)

		previousButton.setTitleColor(UIColor.daisy, for: .normal)
		previousButton.titleLabel?.font = UIFont.textStyle5
		previousButton.contentHorizontalAlignment = .center 

		previousButton.setTitle(NSLocalizedString("string.name", comment: ""),for: .normal)

		previousButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openStudenthomepagecontroller), for: .touchUpInside)

		createAccountLabel.textColor = UIColor.daisy
		createAccountLabel.numberOfLines = 0
		createAccountLabel.font = UIFont.textStyle6
		createAccountLabel.textAlignment = .center
		createAccountLabel.text = NSLocalizedString("create.account2", comment: "")

		email.layer.cornerRadius = 10
		email.layer.masksToBounds =  true
		email.backgroundColor = UIColor.spruce
		email.textColor = UIColor.daisy
		email.font = UIFont.textStyle3
		email.textAlignment = .center
		email.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 10, height: 45))

		email.placeholder = NSLocalizedString("enter.your.email.address", comment: "")


		number.layer.cornerRadius = 10
		number.layer.masksToBounds =  true
		number.backgroundColor = UIColor.spruce
		number.textColor = UIColor.daisy
		number.font = UIFont.textStyle3
		number.textAlignment = .center
		number.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 16, height: 45))

		number.placeholder = NSLocalizedString("enter.your.919.number", comment: "")


		userName.layer.cornerRadius = 10
		userName.layer.masksToBounds =  true
		userName.backgroundColor = UIColor.spruce
		userName.textColor = UIColor.daisy
		userName.font = UIFont.textStyle3
		userName.textAlignment = .center
		userName.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 10, height: 45))

		userName.placeholder = NSLocalizedString("user.name", comment: "")


		password.layer.cornerRadius = 10
		password.layer.masksToBounds =  true
		password.backgroundColor = UIColor.spruce
		password.textColor = UIColor.daisy
		password.font = UIFont.textStyle3
		password.textAlignment = .center
		password.setLeftView(leftViewFrame : CGRect(x: 0, y: 0, width: 10, height: 45))

		password.placeholder = NSLocalizedString("password", comment: "")


		registerButton.layer.cornerRadius = 10
		registerButton.layer.masksToBounds =  true
		registerButton.backgroundColor = UIColor.seafoam
		registerButton.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)
		registerButton.setTitleColor(UIColor.daisy, for: .normal)
		registerButton.titleLabel?.font = UIFont.textStyle3
		registerButton.contentHorizontalAlignment = .center 
		registerButton.contentEdgeInsets = UIEdgeInsets(top: 6, left: 14 , bottom: 6, right: 14)

		registerButton.setTitle(NSLocalizedString("register", comment: ""),for: .normal)

		registerButton.addTarget(self.coordinator, action: #selector(MainCoordinator.openRegistration), for: .touchUpInside)



	}

	private func setupLayout() {
		//Constraints are defined in Storyboard file.
	}

}

