import UIKit

class A: UIButton {

	// MARK: - Initializers
	override init(frame: CGRect) {
		super.init(frame: frame)
		initialize()
	}

	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
		initialize()
	}

	func initialize() {
		applyDefaultStyle()
	}

	// MARK: - Styling
	func applyDefaultStyle() {


		self.layer.cornerRadius = 10
		self.layer.masksToBounds =  true
		self.backgroundColor = UIColor.seafoam
		self.addShadow(color: UIColor(red:0, green: 0, blue: 0, alpha: 1),
		                    alpha: 0.30000001192092896,
		                    x: 0,
		                    y: 4,
		                    blur: 4,
		                    spread: 0)





	}

	func set(){
	}

}
